export enum CategoryType {
    "Books", "Food",  "Drink","Electronics","Groceries","Toys","Baby products"
}
