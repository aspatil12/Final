package org.slk.dao;

public interface AccountsDao {

}
