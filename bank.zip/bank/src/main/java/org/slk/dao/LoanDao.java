package org.slk.dao;

import java.util.List;

import org.slk.model.Loan;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanDao {
	Loan addLoan(Loan loan);
	List<Loan> getAllLoans();
	Loan updateLoan(String loanId,Loan loan);
}
