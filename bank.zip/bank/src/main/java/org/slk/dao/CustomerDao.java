package org.slk.dao;

import java.util.List;

import org.slk.model.Customer;

public interface CustomerDao {
	
	public List<Customer> getAllCustomers() throws Exception;
	 public void updateCustomer(Customer customer);

}
