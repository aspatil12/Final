package org.slk.dao;

import org.springframework.web.bind.annotation.RestController;

@RestController
public interface TransactionDao {
	
	public void withdraw(String un,String pass,int amt);
	public void deposit(String un,String pass,int amt);
	public int transfer(String un,String pass,int amt,int acc_no);
	public void viewbalance(String un,String pass);
	public void viewAlltransactions();
	
}
