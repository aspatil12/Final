package org.slk.dao;

import java.util.List;

import org.slk.model.Branch;
import org.springframework.stereotype.Repository;
@Repository
public interface BranchDao {
	
	List<Branch> getAllBranch();
	Branch updateBranch(String branch_ifsc,Branch branch);
	String deleteBranch(String branch);

}
