package org.slk.dao;




import java.util.List;
import org.springframework.web.bind.annotation.RestController;
import java.sql.SQLException;
import org.slk.model.Admin;

@RestController
public interface AdminDao {
	//public List<Admin> getalladmin() throws Exception;
//	public void add(Employee emp);
	//public String deleteManager(String employee_id);
	public Admin getbyid(String admin_id );
	public Admin update(String admin_id, Admin ad);
	public boolean login(String username, String password) throws Exception ;
}


