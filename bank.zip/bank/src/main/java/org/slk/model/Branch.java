package org.slk.model;

public class Branch {
private String branch_ifsc;
private String branch_name;
private String branch_address;
private long branch_phone;
public Branch() {
	super();
	this.branch_ifsc = branch_ifsc;
	this.branch_name = branch_name;
	this.branch_address = branch_address;
	this.branch_phone = branch_phone;
}
public String getBranch_ifsc() {
	return branch_ifsc;
}
public void setBranch_ifsc(String branch_ifsc) {
	this.branch_ifsc = branch_ifsc;
}
public String getBranch_name() {
	return branch_name;
}
public void setBranch_name(String branch_name) {
	this.branch_name = branch_name;
}
public String getBranch_address() {
	return branch_address;
}
public void setBranch_address(String branch_address) {
	this.branch_address = branch_address;
}
public long getBranch_phone() {
	return branch_phone;
}
public void setBranch_phone(long branch_phone) {
	this.branch_phone = branch_phone;
}


}

