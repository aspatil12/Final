package org.slk.model;

public class Account {
private String account_id;
private String account_type;
private int balance;
private String description; 


public Account(String account_id, String account_type, int balance, String description) {
	super();
	this.account_id = account_id;
	this.account_type = account_type;
	this.balance = balance;
	this.description = description;
}
public String getAccount_id() {
	return account_id;
}
public void setAccount_id(String account_id) {
	this.account_id = account_id;
}
public String getAccount_type() {
	return account_type;
}
public void setAccount_type(String account_type) {
	this.account_type = account_type;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}

}

