package org.slk.model;

import java.util.Date;

public class Customer {
@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_ac_no=" + customer_ac_no + ", customer_name="
				+ customer_name + ", customer_dob=" + customer_dob + ", customer_email=" + customer_email
				+ ", customer_phone=" + customer_phone + ", customer_aadhar=" + customer_aadhar + ", customer_pan="
				+ customer_pan + ", customer_username=" + customer_username + ", customer_password=" + customer_password
				+ ", customer_loan=" + customer_loan + ", customer_branch_ifsc=" + customer_branch_ifsc
				+ ", customer_ac_id=" + customer_ac_id + "]";
	}
private String customer_id;
private long customer_ac_no;
private String customer_name;
private Date customer_dob;
private String customer_email;
private long customer_phone;
private long customer_aadhar;
private String customer_pan;
private String customer_username;
private String customer_password;
private String customer_loan;
private String customer_branch_ifsc;
private String customer_ac_id;
public Customer() {
	super();
	this.customer_id = customer_id;
	this.customer_ac_no = customer_ac_no;
	this.customer_name = customer_name;
	this.customer_dob = customer_dob;
	this.customer_email = customer_email;
	this.customer_phone = customer_phone;
	this.customer_aadhar = customer_aadhar;
	this.customer_pan = customer_pan;
	this.customer_username = customer_username;
	this.customer_password = customer_password;
	this.customer_loan = customer_loan;
	this.customer_branch_ifsc = customer_branch_ifsc;
	this.customer_ac_id = customer_ac_id;
}
public String getCustomer_id() {
	return customer_id;
}
public void setCustomer_id(String customer_id) {
	this.customer_id = customer_id;
}
public long getCustomer_ac_no() {
	return customer_ac_no;
}
public void setCustomer_ac_no(long customer_ac_no) {
	this.customer_ac_no = customer_ac_no;
}
public String getCustomer_name() {
	return customer_name;
}
public void setCustomer_name(String customer_name) {
	this.customer_name = customer_name;
}
public Date getCustomer_dob() {
	return customer_dob;
}
public void setCustomer_dob(Date customer_dob) {
	this.customer_dob = customer_dob;
}
public String getCustomer_email() {
	return customer_email;
}
public void setCustomer_email(String customer_email) {
	this.customer_email = customer_email;
}
public long getCustomer_phone() {
	return customer_phone;
}
public void setCustomer_phone(long customer_phone) {
	this.customer_phone = customer_phone;
}
public long getCustomer_aadhar() {
	return customer_aadhar;
}
public void setCustomer_aadhar(long customer_aadhar) {
	this.customer_aadhar = customer_aadhar;
}
public String getCustomer_pan() {
	return customer_pan;
}
public void setCustomer_pan(String customer_pan) {
	this.customer_pan = customer_pan;
}
public String getCustomer_username() {
	return customer_username;
}
public void setCustomer_username(String customer_username) {
	this.customer_username = customer_username;
}
public String getCustomer_password() {
	return customer_password;
}
public void setCustomer_password(String customer_password) {
	this.customer_password = customer_password;
}
public String getCustomer_loan() {
	return customer_loan;
}
public void setCustomer_loan(String customer_loan) {
	this.customer_loan = customer_loan;
}
public String getCustomer_branch_ifsc() {
	return customer_branch_ifsc;
}
public void setCustomer_branch_ifsc(String customer_branch_ifsc) {
	this.customer_branch_ifsc = customer_branch_ifsc;
}
public String getCustomer_ac_id() {
	return customer_ac_id;
}
public void setCustomer_ac_id(String customer_ac_id) {
	this.customer_ac_id = customer_ac_id;
}

}

