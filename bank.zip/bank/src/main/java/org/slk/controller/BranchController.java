package org.slk.controller;

import java.util.List;

import org.slk.daoimpl.BranchDaoImpl;
import org.slk.model.Branch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class BranchController {
	
	@Autowired
	private BranchDaoImpl branchDaoImpl;
	
	@GetMapping("/branch")
	public List getBranches() {
		return branchDaoImpl.getAllBranch();
	}
	
	@PutMapping("/put/branch/{branch_ifsc}")
	public ResponseEntity updateBranch(@PathVariable String branch_ifsc, @RequestBody Branch branch) {

		branch = branchDaoImpl.updateBranch(branch_ifsc, branch);

		if (null == branch) {
			return new ResponseEntity("No Branch found for ID " + branch_ifsc, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(branch, HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/branch/{branch_ifsc}")
	public ResponseEntity deleteBranch(@PathVariable String branch_ifsc) {

		if (null == branchDaoImpl.deleteBranch(branch_ifsc)) {
			return new ResponseEntity("No Branch found for ID " + branch_ifsc, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(branch_ifsc, HttpStatus.OK);

	}

}
