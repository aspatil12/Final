package org.slk.controller;

import java.util.List;

import org.slk.dao.CustomerDao;
import org.slk.dao.TransactionDao;
import org.slk.model.Customer;
import org.slk.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TransactionController
{
		
		@Autowired
		private TransactionDao transactionDao;
		private Transaction  transaction;
		@GetMapping("/transaction")
		public void viewAlltransactions() throws Exception 
		{
			System.out.println("viewAlltransactions() function inside transaction rest");
			transactionDao.viewAlltransactions();
		}
		
		@GetMapping("/transaction")
		public void viewbalance(String un,String pass)
		{
			System.out.println("viewbalance() function inside transaction rest");
			transactionDao.viewbalance(un,pass);
		}
		
		
		@PostMapping(value="/post/trasaction")
		public void withdraw(@RequestBody String un,@RequestBody String pass,@RequestBody int amt)
		{
			System.out.println("withdraw() function inside transaction rest");
			transactionDao.withdraw(un,pass,amt);
		}
		@PostMapping(value="/post/trasaction")
		public void deposit(@RequestBody String un,@RequestBody String pass,@RequestBody int amt)
		{
			System.out.println("deposit() function inside transaction rest");
			transactionDao.deposit(un,pass,amt);
		}
		
		@PostMapping(value="/post/trasaction")
		public int transfer(String un,String pass,int amt,int acc_no)
		{
			System.out.println("transfer() function inside transaction rest");
			return transactionDao.transfer(un,pass,amt,acc_no);
		}

}

