package org.slk.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.slk.dao.TransactionDao;
import org.slk.util.DButil;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TransactionDaoImpl implements TransactionDao {
	Connection connection = DButil.getConnection();

	public TransactionDaoImpl() {
		connection = DButil.getConnection();
		System.out.println("connection" + connection);
	}
	
	@Override
	public void deposit(String un,String pass,int amt)
	{
		try
		{
		
		String query="select balance from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=st.executeQuery(query);
		rs.next();
		int balance=rs.getInt(1);		
		int bal=balance+amt;
		
		
		
		
		String query1="update customer set balance="+bal+" where customer_username='"+un+"'";
		Statement st1=(Statement) connection.createStatement();
		st1.executeUpdate(query1);
		
		
		System.out.println("Successfully Deposited");
		
		String query4="select customer_ac_no from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st4=(Statement) connection.createStatement();
		ResultSet rs4=((java.sql.Statement) st4).executeQuery(query4);
		rs4.next();
		int accno=rs4.getInt("customer_ac_no");
		
		//credit transaction
		String query5="select max(tid) from transaction";
		Statement st5=connection.createStatement();
		ResultSet rs5=st5.executeQuery(query5);
		int tempId;
		rs5.next();
		tempId=rs5.getInt(1);
		int tid=tempId+1;
		//date
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		  String trans_date=dtf.format(now);  

		  System.out.println("selected accno");
		String query6="insert into transaction values("+tid+",'"+trans_date+"',"+amt+","+0+","+accno+")"; 
		Statement st6=(Statement) connection.createStatement();
		st6.executeUpdate(query6);
		
		}
	   
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	@Override
	public void withdraw(String un,String pass,int amt)
	{
		try
		{
		
		String query="select balance from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=st.executeQuery(query);
		rs.next();
		int balance=rs.getInt(1);		
		int bal=balance-amt;
		
		
		
		
		String query1="update customer set balance="+bal+" where customer_username='"+un+"'";
		Statement st1=(Statement) connection.createStatement();
		st1.executeUpdate(query1);
		
		
		System.out.println("Successfully Withdrawn");
		
		String query4="select customer_ac_no from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st4=(Statement) connection.createStatement();
		ResultSet rs4=((java.sql.Statement) st4).executeQuery(query4);
		rs4.next();
		int accno=rs4.getInt("customer_ac_no");
		
		//credit transaction
		String query5="select max(tid) from transaction";
		Statement st5=connection.createStatement();
		ResultSet rs5=st5.executeQuery(query5);
		int tempId;
		rs5.next();
		tempId=rs5.getInt(1);
		int tid=tempId+1;
		//date
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		   LocalDateTime now = LocalDateTime.now();  
		  String trans_date=dtf.format(now);  

		  System.out.println("selected accno");
		String query6="insert into transaction values("+tid+",'"+trans_date+"',"+amt+","+0+","+accno+")"; 
		Statement st6=(Statement) connection.createStatement();
		st6.executeUpdate(query6);
		
		}
	   
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
	
	
	
	
	@Override
	public int transfer(String un,String pass,int amt,int acc_no)
	{
		try
		{
		
		String query="select balance from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=st.executeQuery(query);
		rs.next();
		int balance=rs.getInt(1);		
		int bal=balance-amt;
		
		System.out.println("testttttttttttt");
		
		
		String query1="update customer set balance="+bal+" where customer_username='"+un+"'";
		Statement st1=(Statement) connection.createStatement();
		st1.executeUpdate(query1);
		
		String query3="select balance from customer where customer_ac_no="+acc_no+"";
		Statement st3=(Statement) connection.createStatement();
		ResultSet rs3=st.executeQuery(query3);
		rs3.next();
		int balance1=rs3.getInt(1);		
		int bal1=balance1+amt;
		System.out.println(bal1);

		String query2="update customer set balance="+bal1+" where customer_ac_no="+acc_no+"";
		Statement st2=(Statement) connection.createStatement();
		st.executeUpdate(query2);
		//System.out.println("Balance="+rs.getInt("balance"));
		System.out.println("Successfully tranferred");
		
		//Transaction table update
				
				String query4="select customer_ac_no from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
				Statement st4=(Statement) connection.createStatement();
				ResultSet rs4=((java.sql.Statement) st4).executeQuery(query4);
				rs4.next();
				int accno=rs4.getInt("customer_ac_no");
				
				//credit transaction
				String query5="select max(tid) from transaction";
				Statement st5=connection.createStatement();
				ResultSet rs5=st5.executeQuery(query5);
				int tempId;
				rs5.next();
				tempId=rs5.getInt(1);
				int tid=tempId+1;
				//date
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				   LocalDateTime now = LocalDateTime.now();  
				  String trans_date=dtf.format(now);  

				  System.out.println("selected accno");
				String query6="insert into transaction values("+tid+",'"+trans_date+"',"+amt+","+0+","+accno+")"; 
				Statement st6=(Statement) connection.createStatement();
				st6.executeUpdate(query6);
				
				//Debit transaction table
				String query7="select max(tid) from transaction";
				Statement st7=connection.createStatement();
				ResultSet rs7=st7.executeQuery(query7);
				int tempId1;
				rs7.next();
				tempId1=rs7.getInt(1);
				int tid1=tempId1+1;
				//date
				DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
				 LocalDateTime now1 = LocalDateTime.now();  
				 String trans_date1=dtf1.format(now1);  

				
				String query8="insert into transaction values("+tid1+",'"+trans_date+"',"+0+","+amt+","+acc_no+")"; 
				Statement st8=(Statement) connection.createStatement();
				st8.executeUpdate(query8);
				
				System.out.println("transaction update");
				
		
		}
	   
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		return 1;
	}
	
	@Override
	public void viewbalance(String un,String pass)
	{
		try
		{
		
		String query="select balance from customer where customer_username='"+un+"' and customer_password='"+pass+"'";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=((java.sql.Statement) st).executeQuery(query);
		
		rs.next();
		System.out.println("Balance="+rs.getInt("balance"));
		}
	   
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	@Override
	public void viewAlltransactions()
	{
		try
		{
		
		String query="select * from transaction";
		Statement st=(Statement) connection.createStatement();
		ResultSet rs=st.executeQuery(query);
		
		while(rs.next())
		{
			
			System.out.print(rs.getInt("tid")+"  ");
			System.out.print(rs.getString("trans_date")+"  ");
			System.out.print(rs.getInt("credit")+"  ");
			System.out.print(rs.getInt("debit")+"  ");
			System.out.print(rs.getInt("acc_no")+"  ");
			System.out.println();
		}
		
		}
		
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}


}
