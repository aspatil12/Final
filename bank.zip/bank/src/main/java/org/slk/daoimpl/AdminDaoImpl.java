package org.slk.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.slk.dao.AdminDao;
import org.slk.model.Admin;
import org.springframework.web.bind.annotation.RestController;

import org.slk.util.DButil;

@RestController
	public class AdminDaoImpl implements AdminDao{
		// Connection connection = null;
		Connection connection = DButil.getConnection();

		public AdminDaoImpl() {
			connection = DButil.getConnection();
			System.out.println("connection" + connection);
		}

		
		@Override
		public Admin getbyid(String admin_id) {
			Admin ad = null;
			try {

				String query = "select * from admin  where admin_role='manager' && admin_id=?;";
				PreparedStatement stmt = connection.prepareStatement(query);
				stmt.setString(1, admin_id);
				ResultSet rs = stmt.executeQuery();
				System.out.println(admin_id);
				while (rs.next()) {
					ad = new Admin();
					ad.setAdmin_id(rs.getString(1));
					ad.setAdmin_name(rs.getString(2));
					ad.setAdmin_role(rs.getString(3));
					ad.setAdmin_username(rs.getString(4));
		
					System.out.println(rs.getString(3));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ad;
		}

		@Override
		public Admin update(String admin_id,Admin ad) {
			System.out.println(admin_id);
			try {
				// emp=new Employee();
				String query = "update admin set admin_name=?,admin_role=?, admin_username=?,admin_password=?,where admin_id=? && admin_role='manager';";
				PreparedStatement stmt = connection.prepareStatement(query);
				stmt.setString(1, ad.getAdmin_name());
				stmt.setString( 2, ad.getAdmin_username());
				stmt.setString(3, ad.getAdmin_password());
				stmt.setString(4, ad.getAdmin_role());
				stmt.setString(5, admin_id);
		
				int res = stmt.executeUpdate();
				if (res > 0) {
					System.out.println("updatation completed");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ad;
		}
		
		public boolean login(String username, String password) throws Exception {
		
		Admin ad = new Admin();
		boolean flag = false;
		PreparedStatement stmt = connection.prepareStatement("select admin_username,admin_password from admin where admin_username=?  and admin_password=? and admin_role='manager'");
		stmt.setString(1, username);
		stmt.setString(2, password);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ad.setAdmin_username(rs.getString(1));
			ad.setAdmin_password(rs.getString(2));
		
			flag = true;
		}
		return flag;
	}

		
	}



