package org.slk.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slk.dao.BranchDao;
import org.slk.model.Branch;
import org.slk.util.DButil;

public class BranchDaoImpl implements BranchDao {

	Connection connection = null;
	private static List<Branch> branches;

	{
		connection = DButil.getConnection();
		System.out.println(connection);
	}

	@Override
	public List<Branch> getAllBranch() {
		String query = "Select * from branch";

		branches = new ArrayList<>();
		PreparedStatement st;
		try {

			st = connection.prepareStatement(query);

			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Branch branch = new Branch();
				String brIfsc = rs.getString(1);
				String brName = rs.getString(2);
				String brAddr = rs.getString(3);
				long brContact = rs.getLong(4);

				branch.setBranch_name(brName);
				branch.setBranch_ifsc(brIfsc);
				branch.setBranch_phone(brContact);
				branch.setBranch_address(brAddr);
				branches.add(branch);

			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return branches;

	}

	@Override
	public Branch updateBranch(String branch_ifsc, Branch branch) {
		try {
			String updSql = "UPDATE  branch set branch_address = ?,branch_phone = ? WHERE branch_ifsc = ?";
			PreparedStatement pst = connection.prepareStatement(updSql);

			pst.setString(1, branch.getBranch_address());
			pst.setLong(2, branch.getBranch_phone());
			pst.setString(3, branch_ifsc);

			int res = pst.executeUpdate();

			if (res > 0) {
				System.out.println("Branch updated");
			}
			return branch;

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String deleteBranch(String branch_ifsc) {
		try {

			String sql = "DELETE FROM branch WHERE branch_ifsc = ? ";
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, branch_ifsc);

			int res = pst.executeUpdate();

			if (res > 0) {
				System.out.println("Branch Deleted");
			}

			return branch_ifsc;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
